import IHttpClient from "./IHttpClient";
import { singleton } from 'aurelia-framework';
import {HttpClient, json} from 'aurelia-fetch-client';


@singleton(AureliaHttpClient)
export default class AureliaHttpClient implements IHttpClient {
  constructor() {
  }

  get apiClient(): any {
    let apiClient = new HttpClient(); 
   
    apiClient.configure(config => {
      config
        .withBaseUrl(process.env.BASE_URL)
        .withDefaults({
          credentials: 'same-origin',
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'Fetch'
          }
        })
        .withInterceptor({
          request(request) {
            return request;
          },
          response(response) {
            return response;
          }
        });
    });

    return apiClient;
  }


  async Delete<TResponse>(url: string): Promise<TResponse> {
    try {
      const aureliaResponse = await this.apiClient.delete(url);
      let response = await aureliaResponse.json();
      return response;
    } catch (err) {
      throw err;
    }
  }

  async Get<TResponse>(url: string): Promise<TResponse> {
    try {

     let aureliaResponse = await this.apiClient.fetch(url, {
        method: 'get'
      });
 
      let response = await aureliaResponse.json();
      return response;
    } catch (err) {
      throw err;
    }
  }

  async Post<TResponse, TRequest>(
    url: string,
    body: TRequest,
  ): Promise<TResponse> {
    try {
      let aureliaResponse = await this.apiClient.fetch(url, {
        method: 'post',
        body:json(body)
      });
      let response = await aureliaResponse.json();
      return response;
    } catch (err) {
      throw err;
    }
  }



  async Put<TResponse, TRequest>(
    url: string,
    body: TRequest
  ): Promise<TResponse> {
    try {
      let aureliaResponse = await this.apiClient.fetch(url, {
        method: 'put',
        body:json(body)
      });  
      let response = await aureliaResponse.json();
      return response;
    } catch (err) {
      throw err;
    }
  }

}
