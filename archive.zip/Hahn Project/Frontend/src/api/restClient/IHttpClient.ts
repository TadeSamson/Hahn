
export default interface IHttpClient {
  Get<TResponse>(url: string,disableAuth?:boolean): Promise<TResponse>;
  Post<TResponse, TRequest>(url: string, body: TRequest,disableAuth?:boolean): Promise<TResponse>;
  Delete<TResponse>(url: string,disableAuth?:boolean): Promise<TResponse>;
  Put<TResponse, TRequest>(url: string, body: TRequest,disableAuth?:boolean): Promise<TResponse>;
}
