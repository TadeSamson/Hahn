// interface IStore {
//   add(key: string, data: string): void;
//   get(key: string): string;
//   remove(key: string): void;
// }

// export default IStore;
