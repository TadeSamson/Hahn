// import { injectable } from "inversify";
// import IStore from "@/api/localStore/IStore";

// @injectable()
// export default class Store implements IStore {
//   constructor() {}

//   add(key: string, data: string): void {
//     if(localStorage.getItem(key)) {
//       localStorage.removeItem(key);
//     }
//     localStorage.setItem(key, data);
//   }

//   get(key: string): string {
//     return localStorage.getItem(key);
//   }

//   remove(key: string): void {
//     localStorage.removeItem(key);
//   }
// }
