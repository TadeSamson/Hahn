import IHttpClient from "./restClient/IHttpClient";
import {IApplicant,} from './models/IApplicant';
import {IResponseMessage} from './models/IResponseMessage';
import {ITResponseMessage} from './models/ITResponseMessage';
import { IGetOption } from './models/IGetOption';
import {inject} from 'aurelia-framework';
import TYPES from "../helper/TYPES";
let config = require("../config.json");




@inject(TYPES.IHttpClient)
export default class ApplicantApi {
  public restClient: IHttpClient;
  constructor(_restClient: IHttpClient) {
    this.restClient = _restClient;
  }

  async CreateApplicant(
    data: IApplicant,
  ): Promise<ITResponseMessage<string>> {
    const resp = await this.restClient.Post<ITResponseMessage<string>, IApplicant>(
      `${config.baseUrl}applicants/add`,data);
    return resp as ITResponseMessage<string>;
  }

  async GetApplicants(option: IGetOption): Promise<ITResponseMessage<IApplicant[]>> {
    let param = JSON.stringify(option);
    let url = `${config.baseUrl}applicants/get?option=${param}`
    const resp = await this.restClient.Get<ITResponseMessage<IApplicant[]>>(url);
    return resp as ITResponseMessage<IApplicant[]>
  }


  async GetApplicant( applicantId: number,option: IGetOption): Promise<ITResponseMessage<IApplicant>> {
    let param="";
    if(option)
     param = JSON.stringify(option);
    let url = `${config.baseUrl}applicants/${applicantId}/get?option=${param}`
    const resp = await this.restClient.Get<ITResponseMessage<IApplicant>>(url);
    
    return resp as ITResponseMessage<IApplicant>;
  }


  async UpdateApplicant(applicantId:number, data: IApplicant): Promise<IResponseMessage> {
    const resp = await this.restClient.Put<IResponseMessage, IApplicant>(
      `${config.baseUrl}}/applicants/${applicantId}/update`,data);
    return resp as IResponseMessage;
  }


  async DeleteApplicant(applicantId: number) {
    return await this.restClient.Delete<IResponseMessage>(
      `${config.baseUrl}applicants/${applicantId}/delete`
    );
  }

}
