export interface IResponseMessage {
  status: string;
  errorMessage: string;
  propertyValidationErrors: IPropertyValidationError[]
}

export interface IPropertyValidationError{
    property:string,
    message:string
}
