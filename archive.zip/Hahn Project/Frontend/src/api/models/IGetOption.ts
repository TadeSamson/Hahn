export interface IGetOption {
    loadedPropertyOption?: ILoadedPropertyOption;
    searchExpression?: string;
    paginationOption?: IPaginationOption;
    sortOption?: ISortOption;
  }

  export interface ILoadedPropertyOption{
      loadedProperties:string[];
  }

  export interface IPaginationOption{
      pageNo:number;
      pageSize:number;
  }


  export interface ISortOption{
    property:string;
    ascending:boolean;
}

