import { IResponseMessage } from "./IResponseMessage";

export interface ITResponseMessage<T> extends IResponseMessage {
  data: T;
}

