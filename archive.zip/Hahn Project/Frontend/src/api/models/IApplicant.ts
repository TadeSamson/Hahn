export interface IApplicant {
  name: string;
  familyName: string;
  address?: string;
  countryOfOrigin:string;
  emailAddress:string;
  image?:string;
  age:number
  id?: number;
  hired?: boolean;
}

