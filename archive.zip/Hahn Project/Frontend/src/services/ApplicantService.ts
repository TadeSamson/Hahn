
import {inject} from 'aurelia-framework';
import { IApplicant } from "../api/models/IApplicant";
import { IResponseMessage } from "../api/models/IResponseMessage";
import { ITResponseMessage } from '../api/models/ITResponseMessage';
import { IGetOption } from '../api/models/IGetOption';
import ApplicantApi from "../api/ApplicantApi";

@inject(ApplicantApi)
export default class ApplicantService {

    applicantApi:ApplicantApi  ;
    constructor(_applicantApi: ApplicantApi ){
            this.applicantApi = _applicantApi;
    }

    async GetApplicants(getOption:IGetOption): Promise<ITResponseMessage<IApplicant[]>>{
        const resp = await this.applicantApi.GetApplicants(getOption);
        return resp;
    }

    async GetApplicant(applicantId:number,getOption:IGetOption): Promise<ITResponseMessage<IApplicant>>{
        const resp = await this.applicantApi.GetApplicant(applicantId,getOption);
        return resp;
    }


    async AddApplicant(applicant:IApplicant): Promise<ITResponseMessage<string>>{
        const resp = await this.applicantApi.CreateApplicant(applicant);
        return resp;
    }

    async DeleteApplicant(applicantId:number): Promise<IResponseMessage>{
        const resp = await this.applicantApi.DeleteApplicant(applicantId);
        return resp;
    }
    
    async UpdateApplicant(applicantId:number,applicant:IApplicant): Promise<IResponseMessage>{
        const resp = await this.applicantApi.UpdateApplicant(applicantId,applicant);
        return resp;
    }


}
