import { Aurelia, PLATFORM, registration } from "aurelia-framework";
import ApplicantApi from "./api/ApplicantApi";
import {initialState} from "./state";
import AureliaHttpClient from "./api/restClient/AureliaHTTPClient";
import TYPES from "./helper/TYPES";
import ApplicantService from "./services/ApplicantService";
import {TCustomAttribute} from 'aurelia-i18n';
import Backend from 'i18next-xhr-backend'; // <-- your previously installed backend plugin




export async function configure(aurelia: Aurelia) {
  aurelia.use
  .standardConfiguration()
   .developmentLogging()
   .plugin(PLATFORM.moduleName('aurelia-validation'))
   .plugin(PLATFORM.moduleName('aurelia-dialog'))
   .plugin(PLATFORM.moduleName('aurelia-store'), { initialState })
   .plugin(PLATFORM.moduleName('aurelia-i18n'), (instance) => {
    let aliases = ['t', 'i18n'];
    // add aliases for 't' attribute
    TCustomAttribute.configureAliases(aliases);

    // register backend plugin
    instance.i18next.use(Backend);

    // adapt options to your needs (see http://i18next.com/docs/options/)
    // make sure to return the promise of the setup method, in order to guarantee proper loading
    return instance.setup({
      backend: {                                  // <-- configure backend settings
        loadPath: './locales/{{lng}}/{{ns}}.json', // <-- XHR settings for where to get the files from
      },
      attributes: aliases,
      lng : 'de',
      fallbackLng : 'en',
      debug : false
    });
  });


    aurelia.start().then(() =>
      {
        aurelia.setRoot(PLATFORM.moduleName("container"));
        aurelia.container.registerSingleton(TYPES.IHttpClient,AureliaHttpClient);
        aurelia.container.registerSingleton(TYPES.ApplicantApi,ApplicantApi);
        aurelia.container.registerSingleton(TYPES.RegistrationPage, registration);
        aurelia.container.registerSingleton(TYPES.ApplicantService,ApplicantService);
      });
}