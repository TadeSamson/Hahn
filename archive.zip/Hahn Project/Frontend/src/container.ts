import {inject} from 'aurelia-framework'
import {RouterConfiguration, Router} from 'aurelia-router';
import { PLATFORM } from "aurelia-framework";


require("./assets/js/bootstrap.bundle.min.js");


@inject (Router)
export class container {
    message: string;
    router:Router;
    constructor() {
    }

    configureRouter(_config: RouterConfiguration, _router: Router) {
      this.router = _router;
      _config.title = 'Applicant Processing Portal';
      _config.options.pushState = true;
      _config.options.root = '/';
      _config.map([
        { route: ['', 'home'],     name: 'home',       viewPorts: { header: { moduleId: PLATFORM.moduleName('components/home-header') }, main: { moduleId: PLATFORM.moduleName('views/home/home') }}},
        { route: ['applicants'],      name: 'applicants',       viewPorts: { header: { moduleId: PLATFORM.moduleName('components/internal-header') }, main: { moduleId: PLATFORM.moduleName('views/applicants/applicants') } } },
        { route: ['applicants/registration'],      name: 'registration',       viewPorts: { header: { moduleId: PLATFORM.moduleName('components/internal-header') }, main: { moduleId: PLATFORM.moduleName('views/registration/registration') } } },
        { route: ['applicants/:id/detail'],      name: 'applicantDetail',       viewPorts: { header: { moduleId: PLATFORM.moduleName('components/internal-header') }, main: { moduleId: PLATFORM.moduleName('views/applicant/applicantDetail') } } },
      ]);
      _config.mapUnknownRoutes(instruction=>{
          instruction.config={ route:['home'], name: 'home', viewPorts: { header: { moduleId: PLATFORM.moduleName('components/internal-header') }, main: { moduleId: PLATFORM.moduleName('views/home/home') }}};
        return instruction.config;
      });
    }
  }