
import { inject, observable } from 'aurelia-framework';
import {I18N} from 'aurelia-i18n';
import { IApplicant } from '../../api/models/IApplicant';
import ApplicantService from "../../services/ApplicantService";
import ConfirmDialog from '../../components/confirm-dialog';
import {DialogService} from 'aurelia-dialog';
import { IGetOption } from '../../api/models/IGetOption';


let config = require("../../config.json");


@inject(I18N,ApplicantService,ConfirmDialog,DialogService)
export default class applicants{
    i18n:I18N;
    confirmDialog:ConfirmDialog;
    dialogService:DialogService;
    applicantService:ApplicantService;
    constructor(_i18n,_applicantService,_confirmDialog,_dialogService){
        this.applicantService=_applicantService;
        this.confirmDialog=_confirmDialog;
        this.dialogService=_dialogService;
        this.i18n=_i18n;
        this.i18n.setLocale(config.language)
            .then( () => {
            // locale is loaded
        });
    }


    applicants:IApplicant[];
    @observable searchTerm:string;


    searchTermChanged(){
        this.getApplicants();
    }


     async getApplicants(){
         try{

            let getOption:IGetOption={};
            if(this.searchTerm){

                /// I wrote this graphAPI like utility for RestAPI and can be projected to the client. 
                /// here is how the client projection works for searching. Can also be used for sorting, pagination etc.
                getOption.searchExpression=`emailAddress%${this.searchTerm}|| name%${this.searchTerm}||address%${this.searchTerm}||familyName%${this.searchTerm}||countryOfOrigin%${this.searchTerm}`;
            }
            let response = await this.applicantService.GetApplicants(getOption);
            if(response.status=="success"){
                this.applicants=response.data;
            }
            else{
                this.dialogService.open({ viewModel: ConfirmDialog, model: {message:response.errorMessage, isOkayCancel:false}, lock: false })
            }
         }
         catch(error){

         }
    }


    bind(){
        this.getApplicants();
    }



    async deleteApplicant(applicant:IApplicant){
        try{
        this.applicants=this.applicants.filter(ap=>ap.id!=applicant.id);
        let response = await this.applicantService.DeleteApplicant(applicant.id);
        if(response.status=="success"){

        }
        else{

        }
    }
    catch(error){
        console.log(error);
    }
    }


    promptApplicantDeletion(applicant){
        this.dialogService.open({ viewModel: ConfirmDialog, model: {message:this.i18n.tr('applicants.applicant_delete_prompt'), isOkayCancel:true}, lock: false }).whenClosed(async response => {
            if (!response.wasCancelled) {
               this.deleteApplicant(applicant);
            } 
          });
    }

}