
import { pluck } from 'rxjs/operators';
import { connectTo } from 'aurelia-store';
import { State } from '../../state';
import { IApplicant } from '../../api/models/IApplicant';
import ApplicantService from '../../services/ApplicantService';
import { inject } from 'aurelia-framework';
import { Store } from 'aurelia-store';
import TYPES from '../../helper/TYPES';
import {I18N} from 'aurelia-i18n';
let config = require("../../config.json");


let defaultImage = require('../../assets/img/unisex-avatar.jpg')



@connectTo<State>({
    selector: {
      applicant: (store) => store.state.pipe(pluck('activeApplicant'))
    },
    setup: 'create',        // create the subscription inside the create life-cycle hook
    teardown: 'deactivate' // do the disposal in deactivate
  })
  @inject(TYPES.ApplicantService,Store,I18N)
export default class applicantDetail{
    applicant:IApplicant;
    applicantService:ApplicantService;
    id:number;
    i18n:I18N;
    status:any={isLoading:false,errorMessage:null}
    constructor(_applicantService,_store,_i18n){
        this.applicantService=_applicantService;

        this.i18n=_i18n;
        this.i18n.setLocale(config.language)
            .then( () => {
            // locale is loaded
        });
    }


    isNew:boolean=false;
    defaultImage:string=defaultImage;

    activate(params,routeConfig,navigationInstruction) {
      this.id = params.id;
      this.isNew=navigationInstruction.queryParams.isNew;
   }

    bind(){
      if(this.applicant==null){
          this.getApplicant();
      }
    }


   async getApplicant(){
     try{
        if(this.status.isLoading)
        return;
        this.status.isLoading=true;
       let response = await this.applicantService.GetApplicant(this.id,null);
       console.log(response);
       if(response.status=="success"){
          this.applicant=response.data;
       }
       else{

       }
       this.status.isLoading=false;
     }
     catch(error){
       this.status.isLoading=false;
       console.log(error);
     }
    }
}