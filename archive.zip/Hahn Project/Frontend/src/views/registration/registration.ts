import { inject, observable } from "aurelia-framework";
import {Router} from 'aurelia-router';
import  {IApplicant} from "../../api/models/IApplicant";
import TYPES from "../../helper/TYPES";
import {DialogService} from 'aurelia-dialog';
import ConfirmDialog from '../../components/confirm-dialog';
import ApplicantService from "../../services/ApplicantService";
import { ValidationControllerFactory, ValidationRules, Validator, validateTrigger, ValidationController  } from 'aurelia-validation';
import { ITResponseMessage } from "../../api/models/ITResponseMessage";
import { State } from "../../state";
import { Store } from 'aurelia-store';
import {I18N} from 'aurelia-i18n';

let config = require( "../../config.json");



let defaultImage = require('../../assets/img/unisex-avatar.jpg')

@inject(TYPES.ApplicantService,ValidationControllerFactory, Validator, Router, Store, ConfirmDialog, DialogService,I18N )
export default class registration{
    applicantService:ApplicantService;
    controller:ValidationController;
    validator:Validator;
    router:Router;
    confirmDialog:ConfirmDialog;
    dialogService:DialogService;
    i18n:I18N;
    store:Store<State>
    constructor(_applicantService,_controllerFactory, _validator,_router, _store,_confirmDialog,_dialogService,_i18n){
        this.applicantService=_applicantService;
        this.canSubmit = false;
        this.confirmDialog=_confirmDialog;
        this.dialogService=_dialogService;


        this.i18n=_i18n;

        this.i18n.setLocale(config.language)
            .then( () => {
            // locale is loaded
            this.submitButtonText=this.i18n.tr("registration.submit");
        });


        /// this validator is attached to the controller. The validation states can be manually  accessed within. 
        /// this is necessary to enable and disable the submit button. 
        this.validator=_validator;
        this.router=_router;
        this.store=_store;
        this.controller = _controllerFactory.createForCurrentScope(this.validator);

        /// by default, aurelia-validation validates on blur, we need to attach a new trigger to allow both blur and change
        /// this is to enable to disable reset or submit button while user types. 
        this.controller.validateTrigger = validateTrigger.changeOrBlur;

        /// whenever any validation changes, the validateWhole is trigger and tries to see if everything is okay 
        /// to enable or disable the submit button
        this.controller.subscribe(event => this.validateWhole());

        /// this is a dispatchable action registration to tell the app state when a new applicants get added
        /// so newly navigated page can use instead of getting from the server
        this.store.registerAction("currentApplicantAction",this.currentApplicantAction);

        ValidationRules
            .ensure('name').required().minLength(5).withMessage(this.i18n.tr("registration.name_error"))
            .ensure('address').required().minLength(10).withMessage(this.i18n.tr("registration.address_error"))
            .ensure('emailAddress').required().email().withMessage(this.i18n.tr("registration.email_error"))
            .ensure('countryOfOrigin').required().minLength(5).withMessage(this.i18n.tr("registration.country_error"))
            .ensure('age').required().between(20,60).withMessage(this.i18n.tr("registration.age_error"))
            .ensure('familyName').required().minLength(5).withMessage(this.i18n.tr("registration.family_name_error"))
            .on(this);
    }

    
    name:string;
    hired:boolean;
    address:string;
    countryOfOrigin:string;
    emailAddress:string;
    age:number;
    defaultImage:string=defaultImage;
    familyName:string;
    isSubmitting:boolean;
    submitButtonText:string;
    canSubmit:boolean;
    image:string;
    id:number
    @observable selectedImages:any


     currentApplicantAction(state: State, applicant: IApplicant) {
        const newState = Object.assign({}, state);
        newState.activeApplicant = applicant;
        return newState;
      }
      
    

    async submit(){
        try{

           let applicant:IApplicant={
                name:this.name,
                age:this.age,
                id:this.id,
                countryOfOrigin:this.countryOfOrigin,
                emailAddress:this.emailAddress,
                familyName:this.familyName,
                address:this.address,
                hired:this.hired?this.hired:false,  
                image:this.image
           }

        if(this.isSubmitting)
        return;
        this.isSubmitting=true;
        let response:ITResponseMessage<string> =  await this.applicantService.AddApplicant(applicant);
         if(response.status=="success"){
             let slices = response.data.split('/');
             let id = slices[slices.length-1];
             applicant.id= Number(id);
             this.store.dispatch(this.currentApplicantAction,applicant);
            this.router.navigateToRoute("applicantDetail",{id,isNew:true});
         }
         else{
            let errorString:string="";
            response.propertyValidationErrors.forEach(pv=>{
                errorString+=`${pv.property}: ${pv.message}\n`;
            });
            if(!errorString)
            errorString=response.errorMessage;
            this.showError(errorString);

         }
         this.isSubmitting=false;
        }
        catch(error){
            this.isSubmitting=false;
            console.log(error);
        }

    }


    selectedImagesChanged(newValue){
    if(newValue.length>0)
    {
        let file = newValue[0];
      var reader = new FileReader();
      reader.onloadend = ()=>{
          this.image=reader.result as string;
      }
      reader.readAsDataURL(file);
    }
    

   }

   promptReset(){
    this.dialogService.open({ viewModel: ConfirmDialog, model: {message:this.i18n.tr('registration.form_reset_prompt'), isOkayCancel:true}, lock: false }).whenClosed(response => {
      if (!response.wasCancelled) {
            this.resetForm();
      } 
    });
  }

  resetForm(){
    this.name=null;
    this.hired=null;
    this.address=null;
    this.countryOfOrigin=null;
    this.emailAddress=null;
    this.age=null;
    this.familyName=null;
    this.image=defaultImage;
  }


  showError(errorMessage){
    this.dialogService.open({ viewModel: ConfirmDialog, model: {message:errorMessage, isOkayCancel:false}, lock: false });
  }


    get canClear():boolean{
        let canClearState= !this.isSubmitting && (this.image||this.name||this.hired||this.address||this.countryOfOrigin||this.age||this.familyName||this.emailAddress);
        return canClearState as boolean;
    }




    private async validateWhole() {
       let results= await  this.validator.validateObject(this);
       this.canSubmit=this.canSubmit = results.every(result => result.valid);
    }

}