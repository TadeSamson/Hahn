import { inject } from 'aurelia-framework';
import {I18N} from 'aurelia-i18n';
let config = require("../../config.json");

@inject(I18N)
export default class home{
    i18n:I18N;
    constructor(_i18n){
        this.i18n=_i18n;
        this.i18n.setLocale(config.language)
            .then( () => {
            // locale is loaded
        });
    }

}