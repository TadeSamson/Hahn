import { inject } from "aurelia-framework";
import {Router} from 'aurelia-router';
import {I18N} from 'aurelia-i18n';
let config = require("../config.json");

@inject(Router,I18N)
export default class internalHeader{
    router:Router;
    i18n:I18N;
    constructor(_router:Router,_i18n){
        this.router=_router;
        this.i18n=_i18n;
        this.i18n.setLocale(config.language)
            .then( () => {
            // locale is loaded
        });
    }


    goBack(){
        this.router.navigateBack();
    }
}