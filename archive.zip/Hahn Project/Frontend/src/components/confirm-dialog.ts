import {DialogController} from 'aurelia-dialog';
import { inject } from 'aurelia-framework';

@inject(DialogController)
export default class ConfirmDialog{
    controller:DialogController;
    message:string;
    isOkayCancel:true;
    constructor(_controller){
        this.controller=_controller;
    }

    activate({message,isOkayCancel}){
        this.message=message;
        this.isOkayCancel=isOkayCancel
    }

}