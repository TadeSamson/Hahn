import { IApplicant } from "./api/models/IApplicant";

  export interface State {
    activeApplicant:IApplicant;
  }
  
  export const initialState: State = {
    activeApplicant:null
  };
  

  