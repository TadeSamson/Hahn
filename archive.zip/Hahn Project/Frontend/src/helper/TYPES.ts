



const TYPES = {
    IHttpClient: Symbol("IHttpClient"),
    ApplicantService: Symbol("ApplicantService"),
    ApplicantApi: Symbol("ApplicantApi"),
    RegistrationPage: Symbol("RegistrationPage"),
  };
  
  export default TYPES;
  