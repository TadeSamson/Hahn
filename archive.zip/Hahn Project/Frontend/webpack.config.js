const { AureliaPlugin } = require('aurelia-webpack-plugin');
  const HtmlWebpackPlugin = require('html-webpack-plugin');
  var webpack = require('webpack');
  var CopyPlugin = require('copy-webpack-plugin');
  var extractTextPlugin =  require("mini-css-extract-plugin");
  const { resolve } = require('path');
  
  var extractPlugin = new extractTextPlugin({
    filename:'[name].css'
  });

  module.exports = function (mode) {
    mode=mode||'development';
    return {
      mode: mode || 'development',
      resolve: {
        extensions: ['.ts', '.js'],
        modules: [
          resolve(__dirname, 'src'),
          resolve(__dirname, 'node_modules'), 
        ]
      },
      entry: {
        // the 'aurelia-bootstrapper' entry point is responsible for resolving your app code
        app: ['aurelia-bootstrapper']
      },
      output: {
        filename: '[name].js',
        path: resolve(__dirname, 'dist')
      },
      watch: mode === 'development',
      devtool: mode === 'development' ? 'inline-source-map' : 'source-map',
      devServer: {
        port: 3111,
        publicPath: "http://localhost:3001/",    //this is where the bundle files are served
        contentBase: './dist',
        historyApiFallback: true
      },
      module: {
        rules: [
          {
            test :/\.(png|jpeg|jpg|mp4|jfif|gif)/,
            use:[
                {
                    loader :'file-loader',
                    options : {
                        name : '[name].[ext]',
                        outputPath : 'img/',
                        esModule:false,
                        publicPath : '/img/'
                    }
                }
            ]
        },  

        {
          test: /\.(woff(2)?|ttf|eot|gif|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,    //to support @font-face rule 
          use:[
              {
                  loader: "url-loader",
                  query:{
                    limit:'1000',
                    name:'fonts/[name].[ext]'
                    //the fonts will be emmited to public/assets/fonts/ folder 
                    //the fonts will be put in the DOM <style> tag as eg. @font-face{ src:url(assets/fonts/font.ttf); }  
                  }
              }
          ]
         },  


         {
          test: /\.css$/i,
          issuer: /\.html?$/i,
          use: [{ loader: "css-loader", options: { esModule: false }}]
        },
        {
          test: /\.css$/i,
          issuer: /\.[tj]s$/i,
          use: ["style-loader", "css-loader"]
        },

       

          { test: /\.html$/i, loader: 'html-loader' },
          { test: /\.ts$/i, loader: 'ts-loader' },


        ]
      },
      plugins: [
        new webpack.ProvidePlugin({
          $: 'jquery',
          jQuery: 'jquery',
          'window.jQuery': 'jquery'
      }),

        // the AureliaPlugin translates Aurelia's conventions to something Webpack understands
        // and must be included in order for Webpack to work
        new AureliaPlugin(),

        new CopyPlugin([
          { from: 'src/locales', to: 'locales' }
        ]), 

        extractPlugin,
        new HtmlWebpackPlugin({
          template: 'index.html',
          metadata: { dev: mode !== 'production' }
        })
      ]
    };
  };
  

  