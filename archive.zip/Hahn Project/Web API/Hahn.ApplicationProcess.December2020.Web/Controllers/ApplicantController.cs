﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Hahn.ApplicationProcess.December2020.Domain.Implementations;
using Hahn.ApplicationProcess.December2020.Domain.Models;
using Hahn.ApplicationProcess.December2020.Web.Data;
using Hahn.ApplicationProcess.December2020.Domain.Utils;
using Hahn.ApplicationProcess.December2020.Domain.Interface;
using Hahn.ApplicationProcess.December2020.Web.Utils;
using System.Net;
using Swashbuckle.AspNetCore.Filters;
using Microsoft.AspNetCore.Http;

namespace Hahn.ApplicationProcess.December2020.Web.Controllers
{


    [ApiController]
    [Produces("application/json")]
    public class ApplicantController
    {

        RepositoryBase<Applicant> applicantRepository;
        IUnitOfWork work; 
        ILogger logger;
        IHttpContextAccessor context;
        ApplicantData_PostValidator validator;

        public ApplicantController(IUnitOfWork _work,
            RepositoryBase<Applicant> _applicantRepository, IHttpContextAccessor _context, ILogger _logger, ApplicantData_PostValidator _validator)
        {
            work = _work;
            validator = _validator;
            context = _context;
            logger = _logger;
            applicantRepository = _applicantRepository;
        }




        #region Applicant Endpoints

        [HttpPost]
        [Route("applicants/add")]
        [SwaggerRequestExample(typeof(ApplicantData_Post), typeof(ApplicantData_PostExample))]
        /// the string response data is the url to get the newly created applicant
        public async Task<ActionResult<ResponseMessage<string>>> AddApplicant(ApplicantData_Post postData)
        {
             ResponseMessage<string> response = new ResponseMessage<string>();
                var validationResult = validator.Validate(postData);
                if (!validationResult.IsValid)
                {
                    response.status = ResponseStatus.failed.ToString();
                response.errorMessage = "one or more field validation failed";
                    response.propertyValidationErrors = validationResult.Errors.Select(error => new PropertyValidationError() { message = error.ErrorMessage, property = error.PropertyName }).ToList();
                    return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.BadRequest };
                }


            GetOption<Applicant> option = new GetOption<Applicant>();
            option.SearchOption = new SearchOption<Applicant>();
            postData.emailAddress = postData.emailAddress.Trim().ToUpper();
            option.SearchOption.Expression = new PropertySearchExpression() { Property=nameof(Applicant.EmailAddress), Operator="=", Value=postData.emailAddress };
            option.PaginationOption = new PaginationOption<Applicant>() { PageNo = 0, PageSize = 1 };
            Applicant existingApplicantWithSameEmail = (await applicantRepository.GetEntitiesAsync(option)).FirstOrDefault();

            if (existingApplicantWithSameEmail != null)
            {
                response.status = ResponseStatus.failed.ToString();
                response.errorMessage = $"Applicant with email address {postData.emailAddress} already exist";
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.Conflict };
            }


                Applicant applicant = new Applicant()
                {
                  Age=postData.age,
                  Address=postData.address,
                  CountryOfOrigin=postData.countryOfOrigin,
                  EmailAddress=postData.emailAddress,
                  FamilyName=postData.familyName,
                  Hired=postData.hired,
                  Name= postData.name
                };

                if (postData.image!=null)
                {
                string base64Header = "data:image/png;base64,";
                postData.image= postData.image.Replace(base64Header, "");
                applicant.Image = ImageHelper.GetThumbnail(postData.image, 20);
                applicant.Image = applicant.Image.Insert(0, base64Header);
                }

                applicantRepository.QueueForAdd(applicant);
                bool result = await work.CommitChangesAsync();
                if (!result)
                {
                    response.status = ResponseStatus.failed.ToString();
                    return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.InternalServerError };

                }
                response.data = $"{context.HttpContext.Request.Scheme}://{context.HttpContext.Request.Host.Value}/applicants/{applicant.Id}";

            response.status = ResponseStatus.success.ToString();
            return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.Created };

        }


        [HttpPut]
        [Route("applicants/{applicantId}/update")]
        [SwaggerRequestExample(typeof(ApplicantData_Post), typeof(ApplicantData_PostExample))]
        public async Task<ActionResult<ResponseMessage>> UpdateApplicant(int applicantId, ApplicantData_Post postData)
        {

            ResponseMessage response = new ResponseMessage();
            var validationResult = validator.Validate(postData);
            if (!validationResult.IsValid)
            {
                response.status = ResponseStatus.failed.ToString();
                response.errorMessage = "one or more field validation failed";
                response.propertyValidationErrors = validationResult.Errors.Select(error => new PropertyValidationError() { message = error.ErrorMessage, property = error.PropertyName }).ToList();
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.BadRequest };
            }


            GetOption<Applicant> option = new GetOption<Applicant>();
            option.SearchOption = new SearchOption<Applicant>();
            postData.emailAddress = postData.emailAddress.Trim().ToUpper();
            SearchExpression emailExp = new PropertySearchExpression() { Property = nameof(Applicant.EmailAddress), Operator = "=", Value = postData.emailAddress };
            SearchExpression idExp = new PropertySearchExpression() { Property = nameof(Applicant.Id), Operator = "=", Value = applicantId.ToString() };
            option.SearchOption.Expression = new BinarySearchExpression<Applicant>() { LeftSearch= emailExp, BinaryOperator="||", RightSearch=idExp };
            List<Applicant> existingApplicants = await applicantRepository.GetEntitiesAsync(option);


            Applicant targetApplicant = existingApplicants.FirstOrDefault(app => app.Id == applicantId);

            if (targetApplicant == null)
            {
                response.status = ResponseStatus.failed.ToString();
                response.errorMessage = $"applicant with id {applicantId} doesn't exit";
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.NotFound };
            }




            Applicant anotherApplicantWithSameEmail = existingApplicants.FirstOrDefault(app => app.Id != targetApplicant.Id);

            if (anotherApplicantWithSameEmail!=null) //means the target user email has changed but someone has the email already. 
            {
                response.status = ResponseStatus.failed.ToString();
                response.errorMessage = $"Applicant with email address {postData.emailAddress} already exist";
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.Conflict };
            }



            targetApplicant.Age = postData.age;
            targetApplicant.CountryOfOrigin = postData.countryOfOrigin;
            targetApplicant.EmailAddress = postData.emailAddress;
            targetApplicant.FamilyName = postData.familyName;
            targetApplicant.Address = postData.address;
            targetApplicant.Hired = postData.hired;
            targetApplicant.Name = postData.name;

            if (postData.image != null)
            {
                string base64Header = "data:image/png;base64,";
                postData.image=postData.image.Replace(base64Header, "");
                targetApplicant.Image = ImageHelper.GetThumbnail(postData.image, 20);
                targetApplicant.Image = targetApplicant.Image.Insert(0, base64Header);
            }

                applicantRepository.QueueForUpdate(targetApplicant);
                bool result = await work.CommitChangesAsync();
            if (!result)
            {
                response.status = ResponseStatus.failed.ToString();
                response.errorMessage = "Something went wrong will updating applicant";
                logger.LogCritical("Couldn't persist applicant update");
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.InternalServerError };
            }
            response.status = ResponseStatus.success.ToString();
            return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.OK };


        }




        [HttpGet]
        [Route("applicants/{applicantId}/get")]
        public async Task<ActionResult<ResponseMessage<ApplicantData>>> GetApplicant(int applicantId, [ModelBinder(typeof(GetOptionBinder<ApplicantData>))]ClientGetOption<ApplicantData> getOption = null)
        {
            ResponseMessage<ApplicantData> response = new ResponseMessage<ApplicantData>();
            GetOption<Applicant> option = getOption.ToModelOption<ApplicantData, Applicant>();


            Applicant applicant = await applicantRepository.GetEntityAsync(applicantId, option);
            if (applicant == null)
            {
                response.status = ResponseStatus.failed.ToString();
                response.errorMessage = $"applicant with id {applicantId} doesn't exist";
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.NotFound };
            }

            response.data = ApplicantData.FromModel(applicant);
            response.status = ResponseStatus.success.ToString();
            return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.OK };


        }


        [HttpGet]
        [Route("applicants/get")]
        public async Task<ActionResult<ResponseMessage<List<ApplicantData>>>> GetApplicants([ModelBinder(typeof(GetOptionBinder<ApplicantData>))]ClientGetOption<ApplicantData> getOption = null)
        {
            ResponseMessage<List<ApplicantData>> response = new ResponseMessage<List<ApplicantData>>();
                GetOption<Applicant> option = getOption.ToModelOption<ApplicantData, Applicant>();

               
                List<Applicant> applicants = await applicantRepository.GetEntitiesAsync(option);
                Dictionary<string, int> usersActivePointDictionary = new Dictionary<string, int>();
                
                response.data = applicants.Select(applicant => ApplicantData.FromModel(applicant)).ToList();


                response.status = ResponseStatus.success.ToString();
            return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.OK };




        }



        [HttpDelete]
        [Route("applicants/{applicantId}/delete")]
        public async Task<ActionResult<ResponseMessage>> DeleteParticipant(int applicantId)
        {
            ResponseMessage response = new ResponseMessage();

                Applicant applicant = await applicantRepository.GetEntityAsync(applicantId);
            if (applicant == null)
            {
                response.status = ResponseStatus.failed.ToString();
                response.errorMessage = $"specified applicant with id {applicantId} doesn't exist";
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.NotFound };

            }

                applicantRepository.QueueForRemove(applicant);
                var result = await work.CommitChangesAsync();
            if (result)
            {
                response.status = ResponseStatus.success.ToString();
                return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.OK };

            }

            string error = "Something went wrong while deleting team";
            logger.LogCritical(error);
            response.errorMessage = error;
            return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.InternalServerError };

        }



        #endregion




    }
}
