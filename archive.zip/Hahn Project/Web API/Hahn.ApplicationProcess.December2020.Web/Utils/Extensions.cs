﻿using Hahn.ApplicationProcess.December2020.Domain.Implementations;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text.RegularExpressions;
using System.Web;

namespace Hahn.ApplicationProcess.December2020.Web.Utils
{
    public static class Extensions
    {
        static string[] fileTypes = { "image/png", "image/jpg", "image/jpeg", "video/mp4", "application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" };
        public static bool IsFile(this string text)
        {
            var type = text.Trim().ToLower();
            if (fileTypes.Any(f => f.Trim().ToLower() == type))
                return true;
            return false;
        }

        public static bool IsJson(this string text)
        {
            return text!=null && text.Trim().ToLower().Contains("application/json");
        }
        public static bool IsText(this string text)
        {
            return text != null && (text.Trim().ToLower().Contains("application/text") || text.Trim().ToLower().Contains("text/plain"));
        }

        public static bool IsValidTextToken(this string text)
        {
            bool isText = new Regex("^[a-z]+[a-z0-9]*", RegexOptions.IgnoreCase).IsMatch(text);
            return isText;
        }

        public static bool IsMultipartFormData(this string text)
        {
            return text != null && text.Trim().ToLower() == "multipart/form-data";
        }

        public static string TrimQuotation(this string text)
        {
            return text.Trim().TrimStart('"').TrimEnd('"');
        }

        public static string ToSentenceCase(this string str)
        {

            if (!String.IsNullOrWhiteSpace(str))
            {
                str = str.ToLower();
                String[] strArray = str.Split(" ");
                for (int i = 0; i < strArray.Length; i++)
                {
                    if (String.IsNullOrWhiteSpace(strArray[i]))
                        continue;
                    strArray[i] = strArray[i] + " "; // This helps prevent out of bound exception if str length is 1
                    strArray[i] = strArray[i].Substring(0, 1).ToUpper() + strArray[i].Substring(1, strArray[i].Length - 1);
                    strArray[i] = strArray[i].Trim();
                }

                return String.Join(" ", strArray);
            }
            return str;

        }

        public static string TrimToLower(this string value)
        {
            return value.Trim().ToLower();
        }

        public static string RemoveHyphen(this string value)
        {

            return value?.Trim().Replace("=", "").Replace("-", "");
        }

        public static finalType To<sourceType,finalType>(this sourceType value, Func<sourceType,finalType> func) 
        {
            if (value == null)
                return default(finalType);
                return func(value);
        }

        //public static String ToClientReadableFormat(this DateTime dateTime)
        //{
        //    if(dateTime!= default(DateTime))
        //    {
        //        return dateTime.ToString("dd/MM/yyyy hh:mm:ss tt");
        //    }
        //    return null;
        //}

        public static string ToUTCFormat(this DateTime dateTime)
        {
            if (dateTime != default(DateTime))
            {
                return dateTime.ToString("yyyy-MM-ddTHH:mm:ssZ");
            }
            return null;
        }


        public static List<string> GetBlobUrls(this string htmlContent)
        {
            if (htmlContent == null)
                return new List<string>();
            htmlContent = HttpUtility.HtmlDecode(htmlContent);
            Regex rg = new Regex(@"\s*src\s*=\s*[\""|'][^\""|']*");
            List<string> matches = new List<string>();
            foreach (Match match in rg.Matches(htmlContent))
            {
                string value = match.Value;
                value = value.Remove(0, (value.IndexOf('"') == -1 ? value.IndexOf('\'') : value.IndexOf('"')) + 1);
                matches.Add(value);
            }
            return matches;
        }

        //public static string ReplaceBase64InHtml(this string html, BlobStorageBase storage)
        //{
        //    //List<string> savedLocations = new List<string>();
        //    Regex rg = new Regex("data:image/[^\"|']*");
        //    Dictionary<string, string> thumbnailDic = new Dictionary<string, string>();

        //    //replacing all base64 src with path after converting base64 to proper image
        //    html = rg.Replace(html, (match =>
        //    {
        //        string[] param = match.Value.Split(',');
        //        byte[] imageBytes = Convert.FromBase64String(param[1]);
        //        Image img = ImageHelper.GetImageFromBytes(imageBytes);
        //        // get thumbnail with size 2% of normal image
        //        int thumbnailWidth = (int)Math.Ceiling((((double)2 / 100) * img.Width));
        //        int thumbnailHeight = (int)Math.Ceiling((((double)2 / 100) * img.Height));
        //        Image thumbnail = img.GetThumbnailImage(thumbnailWidth, thumbnailHeight, null, IntPtr.Zero);
        //        string thumnailString = ImageHelper.GetBase64StringFromImage(thumbnail);
        //        string randomName = Guid.NewGuid().ToString().RemoveHyphen();
        //        string filepath = storage.PutBlob(new Blob() { Bytes= imageBytes, Container= storage.GetDefaultContainer(), Filename= randomName  });
        //        thumbnailDic.Add(filepath, thumnailString);
        //        return filepath;
        //    }));


        //    //Search every replaced src and then append a data-thumbnail attribute containing a light version of the src image
        //    //that will act as the preview image before main src image loads. 
        //    //consumer must replace data-thumbnail value with src while the src path loads. 
        //    foreach (var value in thumbnailDic)
        //    {
        //        string dataSrc = "data-thumbnail=\"" + thumbnailDic[value.Key] + "\"";
        //        int dataSrcStartIndex = html.IndexOf(value.Key.Trim()) + value.Key.Trim().Length + 1; //the 1 is for the omitted quotation "or'
        //        html = html.Insert(dataSrcStartIndex, " " + dataSrc);
        //    }
        //    return html;
        //}



       



        public static string FromNow(this DateTime date)
        {
            TimeSpan timeSpan = date - DateTime.UtcNow;
            double secondsDiff = timeSpan.TotalSeconds;
            secondsDiff = Math.Abs(secondsDiff);
            double yearInSecs = 60 * 60 * 24 * 365;
            double years = Math.Floor(secondsDiff / yearInSecs);
            if (years > 0)
                return years > 1 ? $"{years} years" : $"{years} year";

            double monthInSecs = 60 * 60 * 24 * 30;
            double months = Math.Floor(secondsDiff / monthInSecs);
            if (months > 0)
                return months > 1 ? $"{months} months" : $"{months} month";

            double weekInSec = 60 * 60 * 24 * 7;
            double weeks = Math.Floor(secondsDiff / weekInSec);
            if (weeks > 0)
                return weeks > 1 ? $"{weeks} weeks" : $"{weeks} week";

            double dayInSec = 60 * 60 * 24;
            double days = Math.Floor(secondsDiff / dayInSec);
            if (days > 0)
                return days > 1 ? $"{days} days" : $"{days} days";

            double hourInSec = 60 * 60;
            double hours = Math.Floor(secondsDiff / hourInSec);
            if (hours > 0)
                return hours > 1 ? $"{hours} hours" : $"{hours} hour";

            double minuteInSec = 60;
            double minutes = Math.Floor(secondsDiff / minuteInSec);
            if (minutes > 0)
                return minutes > 1 ? $"{minutes} minutes" : $"{minutes} minute";

            return secondsDiff > 1 ? $"{secondsDiff} seconds" : $"{secondsDiff} second";
        }
    }
}