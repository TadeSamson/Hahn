﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace Hahn.ApplicationProcess.December2020.Web.Utils
{


    /// <summary>
    /// static helper class that resolves clients specified properties (for example, for ClientGetOption<typeparamref name="TModel"/>) 
    /// and match it to property of type TModel. This is required because clients specified properties can be a little different from 
    /// TModel property. For example, when a client pluralize a singular property, we still want to resolve it without any issue. 
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    public static class DataToModelPropertyResolver<TModel>
    {
        static List<PropertyInfo> properties;
        static string TModelName;
        static DataToModelPropertyResolver()
        {
            properties = typeof(TModel).GetProperties().ToList();
            TModelName = typeof(TModel).Name.Trim().ToLower();
        }

        public static PropertyInfo Resolve(string viewDataProperty)
        {
            
            if (viewDataProperty == null)
                return null;
            if (isNextedProperty(viewDataProperty))
            {
                viewDataProperty = getNextedProperty(viewDataProperty);
            }
            var property = properties.FirstOrDefault(p => p.Name.Trim().ToLower() == viewDataProperty.Trim().ToLower());
            if (property == null)
                return null;
            return property;
        }


        /// <summary>
        /// usually, client should specify property as "propertyName" but in scenario where property is specified as "model.propertyName" Resolve utility uses this method to get the property
        /// </summary>
        /// <param name="property"></param>
        /// <returns></returns>
        static bool isNextedProperty(string property)
        {
            return property.Contains(".") && matchModel(property.Split('.')[0]);
        }

        static bool matchModel(string property)
        {
            string[] pluralExtension = new string[] {"s","es" };
            property = property.Trim().ToLower();

            return property.Contains(TModelName) && pluralExtension.Any(plural => property.Replace(TModelName, "").ToLower().Trim() == plural) ;
        }

        static string getNextedProperty(string dottedProperty)
        {
            return dottedProperty.Split('.')[1];
        }
    }
}