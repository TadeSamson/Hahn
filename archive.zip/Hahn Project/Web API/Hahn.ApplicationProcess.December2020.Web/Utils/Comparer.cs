﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace Hahn.ApplicationProcess.December2020.Web.Utils
{
    public class ObjectComparer<T>:IComparer<T>
    {

        string targetPropertyName;
        bool ascending;
        public ObjectComparer(string _targetPropertyName,bool _ascending)
        {
            this.targetPropertyName = _targetPropertyName;
            this.ascending = _ascending;
        }
        public int Compare(T x, T y)
        {
            PropertyInfo property = typeof(T).GetProperties().ToList().Find(p => p.Name.ToLower().Trim() == this.targetPropertyName.ToLower().Trim());
            if (property != null)
            {
                object xValue=property.GetValue(x);
                object yValue=property.GetValue(y);
                if (property.PropertyType.IsPrimitive && 
                    property.PropertyType != typeof(bool) && 
                    property.PropertyType != typeof(char) &&
                    property.PropertyType != typeof(UIntPtr) && 
                    property.PropertyType != typeof(IntPtr))
                {
                    return ascending? (int)xValue - (int)yValue:(int)yValue - (int)xValue;
                }

                if(property.PropertyType==typeof(DateTime))
                {
                    return ascending? (int)((((DateTime)xValue).Ticks - ((DateTime)yValue).Ticks) >> 32 / sizeof(int))
                        :
                        (int)((((DateTime)yValue).Ticks - ((DateTime)xValue).Ticks) >> 32 / sizeof(int));
                }
            }
            throw new Exception(targetPropertyName + " not a valid property of " + this.GetType().Name);
        }
    }
}