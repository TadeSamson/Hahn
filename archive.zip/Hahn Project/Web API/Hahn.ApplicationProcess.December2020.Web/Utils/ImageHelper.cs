﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;



/// <summary>
/// requires CoreCompat.System.Drawing
/// </summary>
namespace Hahn.ApplicationProcess.December2020.Web.Utils
{
    public class ImageHelper
    {
        public static Image GetImageFromBase64String(string image_string)
        {
            byte[] imageBytes = Convert.FromBase64String(image_string);
            return GetImageFromBytes(imageBytes);
        }


        public static Image GetImageFromBytes(byte[] imageBytes)
        {
            MemoryStream ms = new System.IO.MemoryStream(imageBytes);
            Image img = Image.FromStream(ms);
            return img;
        }


        public static string GetBase64StringFromImage(byte[] imageBytes)
        {
            return GetBase64StringFromImage(GetImageFromBytes(imageBytes));
        }

        public static string GetBase64StringFromImage(Image image)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                image.Save(ms, ImageFormat.Png);
                byte[] imageBytes = ms.GetBuffer();
                return Convert.ToBase64String(imageBytes);
            }
        }



        public static string GetThumbnail(string base64String, int reduceToPercent)
        {
            byte[] imageBytes = Convert.FromBase64String(base64String);
            Image thumbnail = GetThumbnail(imageBytes, reduceToPercent);
            return GetBase64StringFromImage(thumbnail);

        }


        public static Image GetThumbnail(byte[] imageBytes, int reduceToPercent)
        {
            using (MemoryStream ms = new MemoryStream(imageBytes))
            {
                Image img = Image.FromStream(ms);
                int thumbnailWidth = (int)Math.Ceiling((((double)reduceToPercent / 100) * img.Width));
                int thumbnailHeight = (int)Math.Ceiling((((double)reduceToPercent / 100) * img.Height));
                Image thumbnail = img.GetThumbnailImage(thumbnailWidth, thumbnailHeight, null, IntPtr.Zero);
                return thumbnail;
            }

        }





   

        public static Image CropImage(Image img, int desireWidth, int desireHeight, int xPoint, int yPoint)
        {
            Bitmap bmp = new Bitmap(desireWidth, desireHeight);

            Graphics graphics = Graphics.FromImage(bmp);
            graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
            graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            //graphics.DrawImage(img, xPoint, yPoint, desireWidth, desireHeight);
            graphics.DrawImage(img, new Rectangle(0, 0, desireWidth, desireHeight), new Rectangle(xPoint, yPoint, desireWidth, desireHeight), GraphicsUnit.Pixel);
            return bmp;
        }
    }
}