﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Web;
using Hahn.ApplicationProcess.December2020.Domain.Utils;
using System.Collections.Specialized;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Hahn.ApplicationProcess.December2020.Web.Utils
{

   public class ClientGetOption<T>
    {
        public LoadedPropertyOption<T> loadedPropertyOption;
        public string searchExpression;
        public PaginationOption<T> paginationOption;
        public SortOption<T> sortOption;
    }
    public class GetOptionBinder<T> : IModelBinder
    {
  

        public  Task BindModelAsync( ModelBindingContext bindingContext)
        {
            var queryString =bindingContext.HttpContext.Request.QueryString.Value;
            queryString = HttpUtility.UrlDecode(queryString);
            ClientGetOption<T> clientGetOption;
            try
            {
                var queryStringAsJson = queryString.Remove(0, queryString.IndexOf("{"));
                queryStringAsJson = queryStringAsJson.Substring(0, queryStringAsJson.LastIndexOf("}")+1);
                 clientGetOption = JsonConvert.DeserializeObject<ClientGetOption<T>>(queryStringAsJson);
                bindingContext.Model = clientGetOption;
                bindingContext.Result = ModelBindingResult.Success(clientGetOption);
                
            }
            catch(Exception ex) {
                using(MemoryStream stream=new MemoryStream())
                {
                    NameValueCollection nvc= HttpUtility.ParseQueryString(queryString);
                    List<KeyValuePair<string, string>> kvpList = new List<KeyValuePair<string, string>>();
                    clientGetOption = new ClientGetOption<T>();
                    foreach (string key in nvc.Keys)
                        switch (key)
                        {
                            case "option[searchExpression]":clientGetOption.searchExpression = nvc[key]; break;
                            case "option[loadedPropertyOption][loadedProperties][]": clientGetOption.loadedPropertyOption = new LoadedPropertyOption<T>();
                                clientGetOption.loadedPropertyOption.LoadedProperties = new List<string>();
                                clientGetOption.loadedPropertyOption.LoadedProperties.AddRange(nvc[key].Split(','));break;
                            case "option[paginationOption][pageSize]": clientGetOption.paginationOption = clientGetOption.paginationOption ?? new PaginationOption<T>();
                                clientGetOption.paginationOption.PageSize = int.Parse(nvc[key]); break;
                            case "option[paginationOption][pageNo]":
                                clientGetOption.paginationOption = clientGetOption.paginationOption ?? new PaginationOption<T>();
                                clientGetOption.paginationOption.PageNo = int.Parse(nvc[key]); break;
                            case "option[sortOption][ascending]":
                                clientGetOption.sortOption = clientGetOption.sortOption ?? new SortOption<T>();
                                clientGetOption.sortOption.Ascending = bool.Parse(nvc[key]); break;
                            case "option[sortOption][property]":
                                clientGetOption.sortOption = clientGetOption.sortOption ?? new SortOption<T>();
                                clientGetOption.sortOption.Property = nvc[key]; break;
                        }

                    bindingContext.Model = clientGetOption;
                    bindingContext.Result = ModelBindingResult.Success(clientGetOption);


                }
            }

            return Task.CompletedTask;
        }



     
    }
}