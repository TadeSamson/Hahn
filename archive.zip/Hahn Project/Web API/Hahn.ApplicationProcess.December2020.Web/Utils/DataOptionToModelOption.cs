﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using Hahn.ApplicationProcess.December2020.Domain.Utils;

namespace Hahn.ApplicationProcess.December2020.Web.Utils
{
    public static class DataOptionToModeOption
    {
        
        public static GetOption<TModel> ToModelOption<TData,TModel>(this ClientGetOption<TData> source/*,Func<string,string> propertyConverter*/)
        {
            if (source == null)
                return null;
            var destination = new GetOption<TModel>();
            destination.PaginationOption = TransformPagination<TData,TModel>(source.paginationOption);
            destination.SortOption = TransformSort<TData, TModel>(source.sortOption);
            destination.SearchOption = new SearchOption<TModel>();
            string searchExpressionWithExcessSpaceRemoved =string.IsNullOrWhiteSpace(source.searchExpression)?null:string.Join(' ', source.searchExpression?.Split(' ').ToList().Where(s => !string.IsNullOrWhiteSpace(s)));
            var TDataExpression = SearchOption<TData>.DeserializeSearchExpression(searchExpressionWithExcessSpaceRemoved);
            destination.SearchOption = TransformSearch<TData,TModel>(new SearchOption<TData>() { Expression = TDataExpression });
            destination.LoadedPropertyOption = TransformLoadedProperty<TData, TModel>(source.loadedPropertyOption);
            return destination;
        }

        static PaginationOption<TModel> TransformPagination<TData,TModel>(PaginationOption<TData> source)
        {
            if (source == null)
                return null;
            PaginationOption<TModel> destination = new PaginationOption<TModel>();
            destination.PageNo = source.PageNo;
            destination.PageSize = source.PageSize;
            if (destination.PageSize <=0 )
                return null;
            return destination;
        }

        static SortOption<TModel> TransformSort<TData,TModel>(SortOption<TData> source)
        {
            if (source == null)
                return null;
            var modelProperty = DataToModelPropertyResolver<TModel>.Resolve(source.Property);
            if (modelProperty == null)
                return null;
            var destination = new SortOption<TModel>();
            destination.Property = modelProperty.Name;
            destination.Ascending = source.Ascending;
            return destination;
        }

        static LoadedPropertyOption<TModel> TransformLoadedProperty<TData, TModel>(LoadedPropertyOption<TData> source)
        {
            if (source == null)
                return null;
            var destination = new LoadedPropertyOption<TModel>();
            foreach (var p in source.LoadedProperties)
            {
                var cp = DataToModelPropertyResolver<TModel>.Resolve(p);
                if (cp!=null)
                    destination.LoadedProperties.Add(cp.Name);
            }
            return destination;
        }

        static SearchOption<TModel> TransformSearch<TData, TModel>(SearchOption<TData> source)
        {
            if (source == null)
                return null;
            var destination = new SearchOption<TModel>();

            destination.Expression = TransformExpression<TData, TModel>(source.Expression);
            return destination;

        }

       // static SearchExpression TransformExpression<TData, TModel>(SearchExpression source)
        static SearchExpression TransformExpression<TData, TModel>(SearchExpression source)
        {
            if (source == null)
                return source;
            if (source is PropertySearchExpression)
            {
                PropertySearchExpression property = new PropertySearchExpression();
                var propertyInfo=DataToModelPropertyResolver<TModel>.Resolve((source as PropertySearchExpression).Property);
                if (propertyInfo == null)
                    return null;
                property.Property = propertyInfo.Name;
                property.Operator = (source as PropertySearchExpression).Operator;
                property.Value = (source as PropertySearchExpression).Value;
                return property;
            }
            
            else
            {
                var expression = new BinarySearchExpression<TModel>();
                expression.RightSearch = TransformExpression<TData, TModel>((source as BinarySearchExpression<TData>).RightSearch);
                expression.LeftSearch = TransformExpression<TData, TModel>((source as BinarySearchExpression<TData>).LeftSearch);
                expression.BinaryOperator = (source as BinarySearchExpression<TData>).BinaryOperator;
                return expression;
            }
        }

        public static bool RequestLoad<TModelOption>(this ClientGetOption<TModelOption> option, Expression<Func<TModelOption,object>> property)
        {
            if (option == null || option.loadedPropertyOption==null)
                return true;
            var expression = property.Body as MemberExpression;

            // literal types like int and string doesn't evaluate their expression as Member Expression but as UnaryExpression
            // try check for literal type RequestLoad
            if (expression == null)
            {
                expression = (property.Body as UnaryExpression).Operand as MemberExpression;
            }           
            string prop = expression.Member.Name;
           return  option.loadedPropertyOption.LoadedProperties.Any(p => p.ToLower().Trim() == prop.Trim().ToLower()  || matchNexted(p,prop));
        }

        static bool matchNexted(string loadedProperty, string prop)
        {
            prop = prop.Trim().ToLower();
            loadedProperty = loadedProperty.Trim().ToLower();
            string[] pluralExension = new string[] {"s","es",string.Empty};
            if (loadedProperty.Contains("."))
            {
                loadedProperty = loadedProperty.Split('.')[0];
                bool result = loadedProperty.Contains(prop) && pluralExension.Any(p => loadedProperty.Replace(prop, "").Trim().ToLower() == p);
                return result;
            }
            return false;
        }
    }
}