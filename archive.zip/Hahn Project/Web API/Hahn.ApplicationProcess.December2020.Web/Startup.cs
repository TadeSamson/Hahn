using Hahn.ApplicationProcess.December2020.Data.Implementation;
using Hahn.ApplicationProcess.December2020.Domain.Implementations;
using Hahn.ApplicationProcess.December2020.Domain.Interface;
using Hahn.ApplicationProcess.December2020.Domain.Models;
using Hahn.ApplicationProcess.December2020.Web.Middlewares;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using FluentValidation.AspNetCore;
using Serilog;
using Hahn.ApplicationProcess.December2020.Web.Data;
using Hahn.ApplicationProcess.December2020.Data.Implementation.HttpClient;
using Microsoft.AspNetCore.Diagnostics;
using Swashbuckle.AspNetCore.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Hahn.ApplicationProcess.December2020.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Hahn.ApplicationProcess.December2020.Web", Version = "v1" });
                c.ExampleFilters();
            });


            services.AddSingleton<IHttpClient>(provider => {
                return new RestSharpHttpClient();
            });

            services.AddScoped<IUnitOfWork>((provider) =>
            {
                return new UnitOfWork();
            });




            services.AddSingleton(provider =>
            {
                var loggerFactory = provider.GetService<ILoggerFactory>();
                return loggerFactory.CreateLogger("General");
            });



            services.AddScoped<RepositoryBase<Applicant>>((provider) =>
            {
                IUnitOfWork work = provider.GetService<IUnitOfWork>();
                return new EntityFrameworkRepository<Applicant>(work);
            });


            /// to allow getting the api url to send when a new entry is made. 
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddMvc().AddFluentValidation();



            services.AddScoped(provider=>
            {
                IHttpClient httpClient = provider.GetService<IHttpClient>();
                return new ApplicantData_PostValidator(httpClient);

            });

            services.AddSwaggerExamples();
            services.AddSwaggerExamplesFromAssemblyOf<ApplicantData_PostExample>();


            /// overiddes the default output and input formatter which will fail to parse empty boolearn property
            services.AddControllers().AddNewtonsoftJson();


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Hahn.ApplicationProcess.December2020.Web v1"));
            }

           
            app.UseHttpsRedirection();

            ///enable log operation earlier in the pipeline
            ///Logger configuration in <see cref="Program"/>
            app.UseSerilogRequestLogging();


            /// A simple middleware to log time used by each request on each endpoints.
            app.UseMiddleware<RequestResponseLoggingMiddleware>();


            app.UseRouting();
           
            app.UseCors(x => x
              .AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader());

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });




            /// this handles global exception and prevents the need for try and catch in each endpoint block
            app.UseExceptionHandler(errorApp =>
            {
                
                errorApp.Run(context =>
                {
                    var host = context.Request.Host.ToUriComponent();
                    var errorFeature = context.Features.Get<IExceptionHandlerFeature>();
                    var exception = errorFeature.Error;
                    var errorDetail = exception.Message;

                    Log.Logger.Error(exception,errorDetail);

                    return null;
                    // in case we need to send to email.
                    //var problemDetails = new ProblemDetails
                    //{
                    //    Title = "An unexpected exception occurred!",
                    //    Status = context.Response.StatusCode,
                    //    Detail = errorDetail,
                    //    Instance = $"Path:{context.Request.Path}, Headers: {context.Request.Headers}, QueryString {(context.Request.QueryString.HasValue ? context.Request.QueryString.Value : "")}, Host: {host}",
                    //    Type = exception.GetBaseException().Message
                    //};
 
                });
            });




        }
    }
}
