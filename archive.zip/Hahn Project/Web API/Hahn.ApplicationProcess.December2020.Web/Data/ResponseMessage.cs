﻿
using System.Collections.Generic;

namespace Hahn.ApplicationProcess.December2020.Web.Data
{
    public class ResponseMessage
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseMessage"/> class.
        /// </summary>
        public ResponseMessage()
        {
        }
        /// <summary>
        /// Gets or sets the status of the response.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string status { get; set; }

        /// <summary>
        /// for specifying generic error message where property is not involved
        /// </summary>
        public string errorMessage { get; set; }

        public List<PropertyValidationError> propertyValidationErrors { get; set; }


    }






    public class ResponseMessage<T> : ResponseMessage
    {
        /// <summary>
        /// Gets or sets the data that would be sent along with the response.
        /// </summary>
        /// <value>
        /// The data object.
        /// </value>
        public T data { get; set; }

    }



    /// <summary>
    /// enumeration of possible error responses
    /// </summary>
    public class PropertyValidationError
    {
        public string property { get; set; }
        public string message { get; set; }
    }

    /// <summary>
    /// enumeration of possible response status
    /// </summary>
    public enum ResponseStatus { failed, success }

    public static class StringExtension
    {
        public static string ReplaceUnderscoreWithSpace(this string value)
        {
            return value.Replace("_"," ");
        }
    }

}