﻿using System.Collections.Generic;
using Hahn.ApplicationProcess.December2020.Web.Utils;
using Hahn.ApplicationProcess.December2020.Domain.Models;
using FluentValidation;
using Hahn.ApplicationProcess.December2020.Domain.Interface;
using System.Threading.Tasks;
using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicationProcess.December2020.Web.Data
{

    public class BaseApplicant
    {
        public string name { get; set; }
        public string familyName { get; set; }
        public string countryOfOrigin { get; set; }
        public string address { get; set; }
        public string emailAddress { get; set; }
        public int age { get; set; }
        /// <summary>
        /// base 64 image string
        /// </summary>
        public string image { get; set; }
        public bool hired { get; set; }
    }
    public class ApplicantData : BaseApplicant

    {

        public int id { get; set; }


        public static ApplicantData FromModel(Applicant model)
        {
            if (model == null)
                return null;

            return new ApplicantData()
            {
                age = model.Age,
                countryOfOrigin = model.CountryOfOrigin,
                emailAddress = model.EmailAddress,
                familyName = model.FamilyName,
                hired = model.Hired,
                address = model.Address,
                id = model.Id,
                image = model.Image,
                name = model.Name
            };

        }

    }

    public class ApplicantData_Post : BaseApplicant
    {
    }



    public class ApplicantData_PostValidator : AbstractValidator<ApplicantData_Post>
    {
        IHttpClient httpClient;
        public ApplicantData_PostValidator(IHttpClient _httpClient)
        {
            httpClient = _httpClient;
            RuleFor(x => x.age).InclusiveBetween(20, 60).WithMessage($"age must be between 20 and 60");
            RuleFor(x => x.countryOfOrigin).MustAsync(async (country, cancellation) =>
            {
                bool isValid = await BeAValidCountryName(country);
                return isValid;
            }).WithMessage($"country of origin is not a valid country");
            RuleFor(x => x.emailAddress).EmailAddress().WithMessage("email address not in correct format"); ;
            RuleFor(x => x.hired).NotNull().When(x => x.hired != null).WithMessage("hired must not a null"); ; // the requirement from the document
            RuleFor(x => x.address).MinimumLength(10).WithMessage($"address must be a minimum of 10 charaters"); ;
            RuleFor(x => x.familyName).MinimumLength(5).WithMessage("family name must be a minimum of 5 characters"); ;
            RuleFor(x => x.name).MinimumLength(5).WithMessage("name must be a minimum of 5 characters"); ;



        }



        private async Task<bool> BeAValidCountryName(string country)
        {
            var result = await httpClient.GetAsync<dynamic>($"https://restcountries.eu/rest/v2/name/{country}?fullText={true}", null);
            return result.IsSuccessful;
        }
    }





    public class ApplicantData_PostExample : IExamplesProvider<ApplicantData_Post>
    {
        public ApplicantData_Post GetExamples()
        {
            return new ApplicantData_Post()
            {
               
             address="7, Maintama Close, Abuja",
             age=29,
             countryOfOrigin="Nigeria",
             emailAddress="queen@qa.team",
             familyName="Ojoruba",
             hired=false,
             image= "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
             name ="Akintade Samson"
            };
        }
    }





}