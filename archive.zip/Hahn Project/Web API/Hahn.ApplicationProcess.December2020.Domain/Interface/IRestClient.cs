﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hahn.ApplicationProcess.December2020.Domain.Utils;

namespace Hahn.ApplicationProcess.December2020.Domain.Interface
{
    public interface IHttpClient
    {
        Task<HttpResult<TReturn>> GetAsync<TReturn>(string endpoint, Dictionary<string, string> headers);

        Task<HttpResult<TReturn>> PostAsync<TReturn, TBody>(string endpoint, Dictionary<string, string> headers, TBody body);

        Task<HttpResult<TReturn>> PutAsync<TReturn, TBody>(string endpoint, Dictionary<string, string> headers, TBody body);

        Task<HttpResult<TReturn>> PatchAsync<TReturn, TBody>(string endpoint, Dictionary<string, string> headers, TBody body);

        Task<HttpResult<TReturn>> DeleteAsync<TReturn>(string endpoint, Dictionary<string, string> headers);

    }
}
