﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.December2020.Domain.Interface
{


    /// <summary>
    /// 
    /// </summary>
    ///
    public interface IEntity
    {
        /// <summary>
        /// Gets or sets the identifier of the model object.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }
    }





}
