﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicationProcess.December2020.Domain.Utils.ExpressionHelper
{
        enum ExpressionType { binary, member, error };
}
