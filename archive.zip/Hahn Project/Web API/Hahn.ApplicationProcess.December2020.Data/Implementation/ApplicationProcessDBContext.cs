﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Hahn.ApplicationProcess.December2020.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicationProcess.December2020.Data.Implementation
{


    public class ApplicationProcessDBContext: DbContext
    {


        public DbSet<Applicant> Applicants { get; set; }

        static DbContextOptions<ApplicationProcessDBContext> options;
        static ApplicationProcessDBContext()
        {
            options = new DbContextOptionsBuilder<ApplicationProcessDBContext>()
            .UseInMemoryDatabase(databaseName: "ApplicationProcessDB")
            .Options;
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }


        /// <summary>
        /// singleton pattern ensuring there's only 1 instance of the DBContext working with 
        /// </summary>
        private static ApplicationProcessDBContext instance = null;
        public static ApplicationProcessDBContext Instance
        {
            get
            {
                if (instance == null)
                    instance = new ApplicationProcessDBContext(options);
                return instance;
            }
        }



        private ApplicationProcessDBContext(DbContextOptions<ApplicationProcessDBContext> options)
       : base(options)
        { }



        //public int SaveChanges<T>() where T : class
        //{
        //    var entityStateGrouping = ChangeTracker.Entries()
        //                .Where(x => !typeof(T).IsAssignableFrom(x.Entity.GetType()) && x.State != EntityState.Unchanged)
        //                .GroupBy(x => x.State);

        //    foreach (var entry in ChangeTracker.Entries().Where(x => !typeof(T).IsAssignableFrom(x.Entity.GetType())))
        //    {
        //        entry.State = EntityState.Unchanged;
        //    }

        //    var rows = SaveChanges();

        //    foreach (var state in entityStateGrouping.ToList())
        //    {
        //        foreach (var entry in state)
        //        {
        //            entry.State = state.Key;
        //        }
        //    }

        //    return rows;
        //}




        public async Task<int> SaveChangesAsync<T>(T entity) where T : class
        {
            var entityStateGrouping = ChangeTracker.Entries()
                        .Where(model => model!=entity  && model.State != EntityState.Unchanged)
                        .GroupBy(model => model.State);

            foreach (var entry in ChangeTracker.Entries().Where(entry => entry.Entity!=entity))
            {
                entry.State = EntityState.Unchanged;
            }

            int rows = await SaveChangesAsync();

            foreach (var state in entityStateGrouping.ToList())
            {
                foreach (var entry in state)
                {
                    entry.State = state.Key;
                }
            }

            return rows;
        }

    }
}
