﻿using Hahn.ApplicationProcess.December2020.Domain.Interface;
using Hahn.ApplicationProcess.December2020.Domain.Utils;
using RestSharp;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.December2020.Data.Implementation.HttpClient
{
    public class RestSharpHttpClient : IHttpClient
    {

        RestClient restClient;
        public RestSharpHttpClient()
        {
            restClient = new RestClient();
        }

        public Task<HttpResult<TReturn>> GetAsync<TReturn>(string endpoint, Dictionary<string, string> headers)
        {

            var request = new RestRequest(endpoint, Method.GET);

            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.AddHeader(header.Key, header.Value);
                }
            }

            return restClient.ExecuteAsync<TReturn>(request).ContinueWith(taskResult =>
            {

                if (taskResult.IsFaulted)
                    throw taskResult.Exception;

                if (taskResult.Result.StatusCode==System.Net.HttpStatusCode.OK)
                {
                    return HttpResult<TReturn>.Success(taskResult.Result.Data);
                }
                return HttpResult<TReturn>.Failure(taskResult.Result.ErrorMessage ?? taskResult.Result.StatusDescription, (int)taskResult.Result.StatusCode);
            });


        }

        public Task<HttpResult<TReturn>> PostAsync<TReturn, TBody>(string endpoint, Dictionary<string, string> headers, TBody body)
        {

            var request = new RestRequest(endpoint, Method.POST);
            request.AddJsonBody(body);
            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.AddHeader(header.Key, header.Value);
                }
            }

            return restClient.ExecuteAsync<TReturn>(request).ContinueWith(taskResult =>
            {

                if (taskResult.IsFaulted)
                    throw taskResult.Exception;

                if (taskResult.Result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return HttpResult<TReturn>.Success(taskResult.Result.Data);
                }
                return HttpResult<TReturn>.Failure(taskResult.Result.ErrorMessage ?? taskResult.Result.StatusDescription, (int)taskResult.Result.StatusCode);
            });



        }


        public Task<HttpResult<TReturn>> PutAsync<TReturn, TBody>(string endpoint, Dictionary<string, string> headers, TBody body)
        {

            var request = new RestRequest(endpoint, Method.PUT);
            request.AddJsonBody(body);
            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.AddHeader(header.Key, header.Value);
                }
            }

            return restClient.ExecuteAsync<TReturn>(request).ContinueWith(taskResult =>
            {

                if (taskResult.IsFaulted)
                    throw taskResult.Exception;

                if (taskResult.Result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return HttpResult<TReturn>.Success(taskResult.Result.Data);
                }
                return HttpResult<TReturn>.Failure(taskResult.Result.ErrorMessage ?? taskResult.Result.StatusDescription, (int)taskResult.Result.StatusCode);
            });



        }

        public Task<HttpResult<TReturn>> PatchAsync<TReturn, TBody>(string endpoint, Dictionary<string, string> headers, TBody body)
        {

            var request = new RestRequest(endpoint, Method.PATCH);
            request.AddJsonBody(body);
            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.AddHeader(header.Key, header.Value);
                }
            }


            return restClient.ExecuteAsync<TReturn>(request).ContinueWith(taskResult =>
            {
               
                if (taskResult.IsFaulted)
                    throw taskResult.Exception;

                if (taskResult.Result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return HttpResult<TReturn>.Success(taskResult.Result.Data);
                }
                return HttpResult<TReturn>.Failure(taskResult.Result.ErrorMessage??taskResult.Result.StatusDescription, (int)taskResult.Result.StatusCode);
            });



        }

        public Task<HttpResult<TReturn>> DeleteAsync<TReturn>(string endpoint, Dictionary<string, string> headers)
        {

            var request = new RestRequest(endpoint, Method.DELETE);

            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.AddHeader(header.Key, header.Value);
                }
            }

            return restClient.ExecuteAsync<TReturn>(request).ContinueWith(taskResult =>
            {

                if (taskResult.IsFaulted)
                    throw taskResult.Exception;

                if (taskResult.Result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return HttpResult<TReturn>.Success(taskResult.Result.Data);
                }
                return HttpResult<TReturn>.Failure(taskResult.Result.ErrorMessage ?? taskResult.Result.StatusDescription, (int)taskResult.Result.StatusCode);
            });


        }

    }
}
