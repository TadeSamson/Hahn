﻿using Hahn.ApplicationProcess.December2020.Domain.Implementations;
using Hahn.ApplicationProcess.December2020.Domain.Interface;
using Hahn.ApplicationProcess.December2020.Domain.Utils;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Transactions;

namespace Hahn.ApplicationProcess.December2020.Data.Implementation
{


    /// <summary>
    /// I normally do not feel comfortable exposing framework implementation like DbContext of entityFramework. Rather,
    /// I always prefer an design pattern that would allow multiple repository use while still abstracting all away from the
    /// consumers. Here, the abstract class <see cref="RepositoryBase{T}"/> is what our consumers will know.
    /// With this approach, we can combine multiple repository while still exposing a single abstract repository to consumers.
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>

    public class EntityFrameworkRepository<T> : RepositoryBase<T> where T : class, IEntity
    {





        /// <summary>
        /// Since we have a Design pattern that supports UnitOfWork, we'll not be exposing entityFramework DBContext to our web application.
        /// We'll only the exposing RepositoryBase which means that at any time, we can decide on changing our Repository layer by just
        /// removing RepositoryBase Implementation and replacing it with say MongoRepository implementation.
        static ApplicationProcessDBContext context;


        static EntityFrameworkRepository()
        {
            context = ApplicationProcessDBContext.Instance;
        }

        public EntityFrameworkRepository(IUnitOfWork _unitOfWork) : base(_unitOfWork)
        {

        }


        public async override Task<List<T>> GetEntitiesAsync(GetOption<T> option = null)
        {
           var result = await context.Set<T>().ToListAsync();

            /// note that this is not an option for production code. It's an extension methods I built into getOption for
            /// repository with no projection or sorting or query feature. For example azure table storage.
            result = option != null && option.SearchOption != null ? result.FindAll(m => option.SearchOption.Match(m)) : result;
            result = option != null && option.SortOption != null ? option.SortOption.Sort(result) : result;
            result = option != null && option.PaginationOption != null ? option.PaginationOption.Paginate<T>(result) : result;


            return result;

        }

        public async override Task<T> GetEntityAsync(int entityId, GetOption<T> option = null)
        {
            var result = await context.Set<T>().FindAsync(entityId);
            return result;

        }

        protected async override Task<int> PersistAddEntityAsync(T entity)
        {

            /// Note that calling context.SaveChanges here doesn't commit all enity with state modified but just this single entity alone.
            /// This is to ensure there's no 
            context.Set<T>().Add(entity);
            var result = await context.SaveChangesAsync(entity);
            return entity.Id;
        }

        protected async override Task<bool> PersistDeleteEntityAsync(T entity)
        {
            context.Set<T>().Remove(entity);
            var result = await context.SaveChangesAsync(entity);
            return result>0;

        }

        protected async override Task<bool> PersistUpdateEntityAsync(T entity)
        {
            context.Set<T>().Update(entity);
            var result = await  context.SaveChangesAsync(entity);
            return result>0;
        }

     
     

    }
}
